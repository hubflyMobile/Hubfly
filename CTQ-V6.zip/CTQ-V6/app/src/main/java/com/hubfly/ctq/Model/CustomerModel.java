package com.hubfly.ctq.Model;

/**
 * Created by Admin on 12-07-2017.
 */

public class CustomerModel {
    int ID;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getClientName() {
        return ClientName;
    }

    public void setClientName(String clientName) {
        ClientName = clientName;
    }

    String ClientName;
}
