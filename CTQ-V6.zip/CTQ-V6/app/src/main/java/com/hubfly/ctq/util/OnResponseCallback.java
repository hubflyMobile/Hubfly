package com.hubfly.ctq.util;

import android.app.Activity;

public interface OnResponseCallback {
    public void responseCallBack(Activity activity, String responseString);
}
