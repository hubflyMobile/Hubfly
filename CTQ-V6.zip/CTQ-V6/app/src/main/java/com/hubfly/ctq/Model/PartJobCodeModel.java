package com.hubfly.ctq.Model;

/**
 * Created by Admin on 18-07-2017.
 */

public class PartJobCodeModel {
    String PartJobCodeHF;
    int ID;

    public String getPartJobCodeHF() {
        return PartJobCodeHF;
    }

    public void setPartJobCodeHF(String partJobCodeHF) {
        PartJobCodeHF = partJobCodeHF;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}
